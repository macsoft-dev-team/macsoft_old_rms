const express = require("express");
const router = express.Router();
const auth = require("./auth");
const { verifyToken } = require("../middleware/auth");
const devices = require("./devices");
const mappings = require("./mappings");
const customers = require("./customers");
const commands = require("./commands");
const templates = require("./templates");
const uploads = require("./uploads");
const dashboard = require("./dashboard");
const users = require("./users");

router.use("/auth", auth);
router.use("/dashboard", verifyToken, dashboard);
router.use("/devices", devices);
router.use("/users", verifyToken, users);
router.use("/mappings", verifyToken, mappings);
router.use("/customers", verifyToken, customers);
router.use("/templates/modbus", verifyToken, templates);
router.use("/commands", verifyToken, commands);
router.use("/upload", verifyToken, uploads);

module.exports = router;
